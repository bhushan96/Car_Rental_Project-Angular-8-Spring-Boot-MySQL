export class Wallet{
    balance;
    userId;
    walletId;
}