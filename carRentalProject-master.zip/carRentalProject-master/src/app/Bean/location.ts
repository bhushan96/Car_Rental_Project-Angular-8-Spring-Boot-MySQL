export interface Locations{
    id:number;
    locality:string;
    city:string;
}