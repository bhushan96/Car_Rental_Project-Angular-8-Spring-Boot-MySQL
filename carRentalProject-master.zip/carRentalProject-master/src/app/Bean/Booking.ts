import { User } from './User'
import { Car } from './Car';

    export class Booking{
    
    bookingId;
	
	fromDate;
	
    tillDate;
    
    bookingDate;
	
	status;
		
userDetails : User;
	
    car : Car;
    
    }